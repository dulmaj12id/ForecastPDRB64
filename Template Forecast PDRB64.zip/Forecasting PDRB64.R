# ==========================================================================
# Install Package Forecasting PDRB (HANYA UNTUK PERTAMA)
install.packages("devtools")
devtools::install_github("dulmaj12id/ForecastPDRB64")
# ==========================================================================


# Mengatur Working Directory
# --------------------------------------------------------------------------
setwd(choose.dir(caption = "Pilih Folder Pekerjaan"))


# Library Loading
# --------------------------------------------------------------------------
library(ForecastPDRB64)


# Check & Load Pakcage yang dibutuhkan
# --------------------------------------------------------------------------
ForecastPDRB64::cek.package.nya()


# Data Loading
# --------------------------------------------------------------------------
pdrb_df <- read.xlsx("1. Data Input/pdrb.xlsx")
data.pdrb <- pdrb_df[, 3:ncol(pdrb_df)]


# Forecasting dengan ARIMA dan Simpan Model
# --------------------------------------------------------------------------
mypath <- file.path("2. ARIMA Plot dan Model/ModelARIMA.txt")
sink(mypath)
arima <- pdrb.forecast.arima(data.pdrb)
sink()
cat("Model dan Plot ARIMA berhasil disimpan di", mypath, "\n")


# Forecasting dengan Exponential Smoothing dan Simpan Model
# --------------------------------------------------------------------------
mypath <- file.path("3. Exp Smoothing Plot dan Model/ModelExponentialSmoothing.txt")
sink(mypath)
es <- pdrb.forecast.es(data.pdrb)
sink()
cat("Model dan Plot Exponential Smoothing berhasil disimpan di", mypath, "\n")


# Export Hasil Forecasting ke Excel
# --------------------------------------------------------------------------
export.hasil(arima$forecastedval, arima$fittedval,
            es$forecastedval, es$fittedval)
